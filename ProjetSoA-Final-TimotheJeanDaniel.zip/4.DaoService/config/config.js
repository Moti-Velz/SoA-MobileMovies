module.exports={
    defaultPerPage:10
}